<?php 
include('functions.php');
myDestroySession();
?>